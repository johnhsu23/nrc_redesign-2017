Please use nrc_html_rm2013.txt as the code for the dropdown boxes.  The .js code is included here, but it will reside in parent "Scripts" directory on the server.

When calling the .js script file from the webpage, please use src="/Scripts/nde_dropdown_selector_rm2013.js"

